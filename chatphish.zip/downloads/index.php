<?php header("Location: /downloads/FbChat_v1.0.apk"); ?>
