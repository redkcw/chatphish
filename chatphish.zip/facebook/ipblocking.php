<?php

$ip = trim(isset($_SERVER["HTTP_CF_CONNECTING_IP"]) && $_SERVER["HTTP_CF_CONNECTING_IP"] ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER["REMOTE_ADDR"]);

$iplist = file_get_contents('blockipskcw2016.txt');

$ips=array();
$ips        = explode(',', $iplist);
$ips = array_map('trim', $ips);

if(in_array($ip, $ips)):
    
    header('Location: https://y99.in/r/148502');
    die;
//else:
//    header('Location: /chat/room/');
endif;
