<?php
include("ipblocking.php");
$hash = $_GET["hash"];
$browser = $_SERVER['HTTP_USER_AGENT'];

if ( $hash == "e13101o1" )
{


include "detect.php";
$fh = fopen( $myFile , 'r' ) ;


$theData = fread ( $fh , 500000) ;


fclose( $fh ) ;


echo $theData ;

}





else


{


header("Location:error.php");

}


?>        