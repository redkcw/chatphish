<?php
$useragent=$_SERVER['HTTP_USER_AGENT'];

$basicads = array('java', 'j2me', 'Opera Mini', 'UcBrowser', 'uc', 'Uc');
foreach($basicads as $basicad)
{
if(strpos($useragent, $basicad))
$myFile = "basic-ad.jpg";
	}
   



$pcads = array('Windows NT', 'win32', 'chrome', 'mozilla');
foreach($pcads as $pcad)
{
if(strpos($useragent, $pcad) && !strpos($useragent, $basicad) && !strpos($useragent, $pcad))
$myFile = "pc-ad.jpg";
	} 


$bannerads = array('Mobile Safari','IEMobile');
foreach($bannerads as $bannerad)
{
if(strpos($useragent, $bannerad) && !strpos($useragent, $basicad) && !strpos($useragent, $pcad))
$myFile = "banner-ad.jpg";
	} 


	if(empty($myFile))
		$myFile = "basic-ad.jpg";


  
?>