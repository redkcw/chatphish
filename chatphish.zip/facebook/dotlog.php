<?php

include("ipblocking.php");
/* counter */

//opens countlog.txt to read the number of hits
$datei = fopen("countdotlog.txt","r");
$count = fgets($datei,1000);
fclose($datei);
$count=$count + 00.10 ;
echo "$count" ;
echo "\n" ;

// opens countlog.txt to change new hit number
$datei = fopen("countdotlog.txt","w");
fwrite($datei, $count);
fclose($datei);

?>