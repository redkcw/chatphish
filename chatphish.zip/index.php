<html>
<head>
	<title>Chat</title>
	<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="static/materialize.min.css" media="screen,projection">
	<style type="text/css">
        .my-message {
            float: right;
            border-radius: 5px;
            padding: 10px;
            background-color: #4caf50;
            color: white;
            text-align: right;
        }
        .others-message {
            float: left;
            border-radius: 5px;
            padding: 10px;
            background-color: #21ade7;
            color: white;
            text-align: left;
        }
        .message-row {
            margin: 0;
        }
        p {
            margin: 2px;
        }
        .nickname-chat {
            font-weight: bold;
            font-style: italic;
            font-size: small;
        }
	</style>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>
<body>
    <div class="row">
    
    </div>
	<div class="row">
		<div class="col s3">
            <img class="responsive-img" src="http://www.mericar.com/chat_logo.png">
			<div class="collection" id="nickname-list">
	    	</div>
		</div>
		
			<button class="btn waves-effect waves-light" onclick="window.location.href='/chat/'" style="width: 100%">Start Messaging</button>
            
            
            
            <button class="btn waves-effect waves-light" onclick="window.location.href='/downloads'" style="width: 100%">Downloads Android APP</button>
		</div>
	</div>

       
        
    </script>
</body>

</html>
